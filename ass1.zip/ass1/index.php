<!DOCTYPE html>
<html>
	<head>
		<title>Cross Site Request Forgery Protection</title>
	</head>
	<body>
		<form action="output.php" method="post">
			<div class="login">
				<strong>Login Form</strong><br><br>
					<div class="credentials">
							Username: <input type="text" name="username"><br><br>
							Password: <input type="text" name="password"><br><br>
					</div>
					<input type="Submit" value="Login">
					
			</div>
		</form>
	</body> 
</html>

